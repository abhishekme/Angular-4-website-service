<?php

namespace App\Http\Controllers;

use Laravel\Lumen\Routing\Controller as BaseController;
use DB;
use App\Country;
use App\State;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Hash;

class CountryController extends BaseController
{

    public function getRecordById(Request $request){
		//Do the needful
		$recordData 	=	Country::where('id',$request->input('id'))->get();

		$respJSON   =   array(
			'status'    	=>  1,
			'respCode'  	=>  200,
			'userData'		=> $recordData,
			'message' 		=> "Total Record"
		);
		return response()->json($respJSON);
		exit;
    }
    
    public function getStateByCountry(Request $request){
        //Do the needful
        
        if(empty($request->input('country_id'))){
			
			$respJSON   =   array(
				'status'    	=>  0,
				'respCode'  	=>  400,
				'message' 		=> "Country ID is empty"
			);
			return response()->json($respJSON);
			exit;
        }

        $recordData 	=	State::where('country_id',$request->input('country_id'))
                                ->orderBy('state_name', 'ASC')
                                ->get();

		$respJSON   =   array(
			'status'    	=>  1,
			'respCode'  	=>  200,
			'userData'		=> $recordData,
			'message' 		=> "Total State Record"
		);
		return response()->json($respJSON);
		exit;
	}

    public function getTotalRecord(Request $request){

		$srchKey 	=	'';
		$recordData 	=	Country::get();
		if(!empty($request->input('srchKey'))){
			$srchKey = $request->input('srchKey');

			$recordData 	=	Country::where('country_name',$srchKey)
							->get();
        }	
        $pageLimit 	=	1;
		$totalData	=	$recordData->count();
        $totalPage 	=	ceil(($totalData)/$pageLimit);
        
        if(!empty($request->input('limitNum'))){
            $limitNum   = $request->input('limitNum');
            $pageLimit 	=	$limitNum;
            $totalData	=	$recordData->count();
            $totalPage 	=	ceil(($totalData)/$pageLimit);
		}		
		
		$respJSON   =   array(
			'status'    	=>  1,
			'respCode'  	=>  200,
			'totalRecord'	=>	$totalData,
			'totalPage'		=>	$totalPage,
			'pageLimit'		=>	$pageLimit,
			'message' 		=> "Total Record"
		);
		return response()->json($respJSON);
		exit;
	}
	
	public function getListRecord(Request $request){

		$limitNum	=	1000;
		$pageNum	=	1;
		$srchKey	=	'';

		    /*if(empty($request->input('limitNum')) && 
			empty($request->input('pageNum'))){
			
			$respJSON   =   array(
				'status'    	=>  0,
				'respCode'  	=>  400,
				'message' 		=> "Limit and Page Number empty"
			);
			return response()->json($respJSON);
			exit;
            }*/
		
		if(!empty($request->input('limitNum'))){
			$limitNum = $request->input('limitNum');
		}
		if(!empty($request->input('pageNum'))){
			$pageNum = $request->input('pageNum');
		}
		if(!empty($request->input('srchKey'))){
			$srchKey = $request->input('srchKey');
		}
		if(!empty($request->input('queryType'))){
			$queryType = $request->input('queryType');
		}


		if(!empty($queryType) && $queryType === 'sort'){
			if(!empty($request->input('sortByField'))){
				$sortByField = $request->input('sortByField');
			}
			if(!empty($request->input('sortByDir'))){
				$sortByDir = $request->input('sortByDir');
			}
		}

		if(!empty($queryType) && $queryType === 'sort'){
			$recordData 	=Country::forPage($pageNum,$limitNum)
							->orderBy($sortByField, $sortByDir)
							->get();
		}
		if(empty($queryType)){
			$recordData 	=Country::forPage($pageNum,$limitNum)
							->get();
		}

		if(!empty($srchKey) && !empty($queryType) && $queryType === 'sort'){
			$recordData 	=Country::where('country_name',$srchKey)
							->forPage($pageNum,$limitNum)
							->orderBy($sortByField, $sortByDir)
							->get();
		}
		if(!empty($srchKey) && empty($queryType)){
			$recordData 	=Country::where('country_name',$srchKey)
							->forPage($pageNum,$limitNum)
							->get();
		}	

		$respJSON   =   array(
			'status'    	=>  1,
			'respCode'  	=>  200,
			'record'		=>	$recordData,
			'message' 		=> "List Record"
		);
		return response()->json($respJSON);
		exit;

	}

	public function editRecord(Request $request){

		if(!$request->input('id')){
			$respJSON   =   array(
				'status'    	=>  0,
				'respCode'  	=>  400,
				'record'		=>	NULL,
				'message' 		=> "Please provide valid ID"
			);
			return response()->json($respJSON);
			exit;
		}

		$recordData 	=	Country::where('id',$request->input('id'))->get();

		$respJSON   =   array(
			'status'    	=>  1,
			'respCode'  	=>  200,
			'record'		=>	$recordData,
			'message' 		=> "Edit Record"
		);
		return response()->json($respJSON);
		exit;
	}

	public function deleteRecord(Request $request){

		if(!$request->input('id')){
			$respJSON   =   array(
				'status'    	=>  0,
				'respCode'  	=>  400,
				'record'		=>	NULL,
				'message' 		=> "Please provide valid ID"
			);
			return response()->json($respJSON);
			exit;
		}
		$recordDelete 	=	Country::where('id',$request->input('id'))->delete();
		$respJSON   =   array(
			'status'    	=>  1,
			'respCode'  	=>  200,
			'record'		=>	$recordDelete,
			'message' 		=> "Selected Record Deleted"
		);
		return response()->json($respJSON);
		exit;
	}

    public function savingRecord(Request $request){

		$errValidate 	=	array();
		$errString 		=	'';	
		$arrayData		=	array();
		$inputPost 		=	$request->all();
		$dataId 		=	'';

		if($request->input('id')){
			$dataId 	=	$request->input('id');
		}

		//print_r($request->file('userPhoto'));		
		//echo 'sss '.$request->file('userPhoto')->getMimeType();
		//echo 'size::: '.$fileObj->getSize();

		try {
			$fileObj = $request->file('countryPhoto');
		}
		catch (\FileNotFoundException $e) {
			$respJSON   =   array(
                'status'    =>  0,
                'respCode'  =>  400,
                'message' => 'Please upload max file within 1 MB'
            );
            return response()->json($respJSON);
            exit;
		    }
        catch (\ErrorException $e) {
                $respJSON   =   array(
                    'status'    =>  0,
                    'respCode'  =>  400,
                    'message' => 'Please upload max file within 1 MB'
                );
                return response()->json($respJSON);
                exit;
            }

		$validation = Validator::make($request->all(),
		    [
				'country_name' 		=> 'required|unique:apps_countries,country_name,'.$dataId,
				'country_code'		=> 'required|unique:apps_countries,country_code,'.$dataId
        	]
		);

        if($validation->fails()){
        	$errorsValidation 	=	$validation->messages();
        	if(!empty($errorsValidation)){
        		foreach ( $errorsValidation->all() as $error ) {
			        array_push($errValidate,$error);
			    }
        	}
        	$respJSON   =   array(
                'status'    =>  0,
                'respCode'  =>  400,
                'message' => $errValidate
            );
            return response()->json($respJSON);
            exit;
        }
        
		if($inputPost){
			if($dataId > 0){
				$userObj 				=	Country::findOrFail($dataId);
			}
			$postData 		=	array(
				'country_name'	    =>	$inputPost['country_name'],
				'country_code'		=>	$inputPost['country_code']
            );
            
			if(Input::file('countryPhoto')){

				try{
					$fileObj = Input::file('countryPhoto');

					$fileName 		=	$fileObj->getClientOriginalName();
					$fileOrigExt 	=	$fileObj->getClientOriginalExtension();
					$fileSize		=	$fileObj->getSize();
					$fileType		=	$fileObj->getMimeType();

					$fileInputSize 	=	$fileObj->getClientSize();

					$pictureName = time().'.'.$fileOrigExt;
					$publicPath 	=	app()->basePath('public/uploads/country/');
					$fileObj->move($publicPath, $pictureName);
					$postData['country_pic']	= $pictureName;
				}catch(FileNotFoundException $ex){
					echo 'Exception image: ';
					exit;
				}
					
            }
            
			if($dataId > 0){
				$objUser 	=	$userObj->update($postData);
			}else{
				$objUser 	=	Country::create($postData);
			}

			if($objUser){
				$respJSON   =   array(
                'status'    =>  1,
                'respCode'  =>  200,
                'message' 	=> 'New Record Modified'
            	);
            return response()->json($respJSON);
            exit;
			}
			$respJSON   =   array(
                'status'    =>  0,
                'respCode'  =>  401,
                'message' 	=> 'Record Insertion/Updation Failed!'
            	);
            return response()->json($respJSON);
            exit;
		}
	}
}
