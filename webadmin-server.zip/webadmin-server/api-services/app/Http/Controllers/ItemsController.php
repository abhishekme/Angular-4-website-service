<?php

namespace App\Http\Controllers;

use Laravel\Lumen\Routing\Controller as BaseController;
use DB;
use App\Items;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Hash;

class ItemsController extends BaseController
{

    public function getRecordById(Request $request){
		//Do the needful
		$itemsRecord 	=	Items::where('id',$request->input('id'))->get();

		$respJSON   =   array(
			'status'    	=>  1,
			'respCode'  	=>  200,
			'itemsData'		=> $itemsRecord,
			'message' 		=> "items Total Record"
		);
		return response()->json($respJSON);
		exit;
	}
	
	public function exportRecord(){

		$itemsRecord 	=	Items::get();

		//print_r($itemsRecord);
		echo json_encode($itemsRecord);
	}

    public function getTotalRecord(Request $request){

		$srchKey 	=	'';
		$itemsData 	=	Items::get();
		if(!empty($request->input('srchKey'))){
			$srchKey = $request->input('srchKey');

			$itemsData 	=	Items::where('item_name',$srchKey)
							->orWhere('price', 'like', '%' . $srchKey . '%')
							->orWhere('qty', 'like', '%' . $srchKey . '%')
							->get();
		}	

		$pageLimit 	=	3;
		$totalData	=	$itemsData->count();
		$totalPage 	=	ceil(($totalData)/$pageLimit);
		
		$respJSON   =   array(
			'status'    	=>  1,
			'respCode'  	=>  200,
			'totalRecord'	=>	$totalData,
			'totalPage'		=>	$totalPage,
			'pageLimit'		=>	$pageLimit,
			'message' 		=> "Items Total Record"
		);
		return response()->json($respJSON);
		exit;
	}
	
	public function getListRecord(Request $request){

		$limitNum	=	0;
		$pageNum	=	0;
		$srchKey	=	'';

		$sortByField 	=	'item_name';
		$sortByDir 		=	'asc';

		if(empty($request->input('limitNum')) && 
			empty($request->input('pageNum'))){
			
			$respJSON   =   array(
				'status'    	=>  0,
				'respCode'  	=>  400,
				'message' 		=> "Limit and Page Number empty"
			);
			return response()->json($respJSON);
			exit;
		}

		if(!empty($request->input('limitNum'))){
			$limitNum = $request->input('limitNum');
		}
		if(!empty($request->input('page'))){
			$pageNum = $request->input('page');
		}
		if(!empty($request->input('srchKey'))){
			$srchKey = $request->input('srchKey');
		}
		if(!empty($request->input('sortByField'))){
			$sortByField = $request->input('sortByField');
		}
		if(!empty($request->input('sortByDir'))){
			$sortByDir = $request->input('sortByDir');
		}

		$itemsData 	=	Items::forPage($pageNum,$limitNum)
						//->orderBy($sortByField, $sortByDir)
						->get();
		if(!empty($srchKey)){
			/*$itemsData 	=	Items::where('item_name','like',"'%".$srchKey."%'")
							->get();
			*/
			$itemsData 	=	Items::where('item_name', $srchKey)
    					->orWhere('item_name', 'like', '%' . $srchKey . '%')->get();
							//->forPage($pageNum,$limitNum)
							//->orderBy($sortByField, $sortByDir)
							
		}

		//print_r($itemsData);
		//exit;

		$respJSON   =   array(
			'status'    	=>  1,
			'respCode'  	=>  200,
			'record'		=>	$itemsData,
			'message' 		=> "Items List Record"
		);
		return response()->json($respJSON);
		exit;

	}

	public function editItems(Request $request){

		if(!$request->input('id')){
			$respJSON   =   array(
				'status'    	=>  0,
				'respCode'  	=>  400,
				'record'		=>	NULL,
				'message' 		=> "Please provide valid ID"
			);
			return response()->json($respJSON);
			exit;
		}

		$itemsRecord 	=	Items::where('id',$request->input('id'))->get();

		$respJSON   =   array(
			'status'    	=>  1,
			'respCode'  	=>  200,
			'record'		=>	$itemsRecord,
			'message' 		=> "Selected Items Record"
		);
		return response()->json($respJSON);
		exit;
	}

	public function deleteItems(Request $request){

		if(!$request->input('id')){
			$respJSON   =   array(
				'status'    	=>  0,
				'respCode'  	=>  400,
				'record'		=>	NULL,
				'message' 		=> "Please provide valid ID"
			);
			return response()->json($respJSON);
			exit;
		}
		$ItemsDelete 	=	Items::where('id',$request->input('id'))->delete();
		$respJSON   =   array(
			'status'    	=>  1,
			'respCode'  	=>  200,
			'record'		=>	$itemsDelete,
			'message' 		=> "Selected Items Deleted"
		);
		return response()->json($respJSON);
		exit;
	}

    public function savingItems(Request $request){

		$errValidate 	=	array();
		$errString 		=	'';	
		$arrayData		=	array();
		$inputPost 		=	$request->all();
		$dataId 		=	'';

		if($request->input('id')){
			$dataId 	=	$request->input('id');
		}

		//print_r($request->file('image'));		
		//echo 'sss '.$request->file('image')->getMimeType();
		//echo 'size::: '.$fileObj->getSize();

		try {
			$fileObj = $request->file('image');
		  }
		  catch (\FileNotFoundException $e) {
			echo 'Exception 1'.$e->getMessage();
			$respJSON   =   array(
                'status'    =>  0,
                'respCode'  =>  400,
                'message' => 'Please upload max file within 1 MB'
            );
            return response()->json($respJSON);
            exit;
		}
		catch (\ErrorException $e) {
			echo 'Exception 2'.$e->getMessage();
			$respJSON   =   array(
                'status'    =>  0,
                'respCode'  =>  400,
                'message' => 'Please upload max file within 1 MB'
            );
            return response()->json($respJSON);
            exit;
		}

		$validation = Validator::make($request->all(),
		    [
				'item_name' => 'required|unique:item_master,item_name,'.$dataId,
	        	'price' 	=> 'required',
				'qty' 		=> 'required',
				'image'		=> 'image | mimes:jpeg,jpg,png | max:1000'
        	]
		);

        if($validation->fails()){
        	$errorsValidation 	=	$validation->messages();
        	if(!empty($errorsValidation)){
        		foreach ( $errorsValidation->all() as $error ) {
			        array_push($errValidate,$error);
			    }
        	}
        	$respJSON   =   array(
                'status'    =>  0,
                'respCode'  =>  400,
                'message' => $errValidate
            );
            return response()->json($respJSON);
            exit;
		}

		if($inputPost){
			if($dataId > 0){
				$itemsObj 				=	Items::findOrFail($dataId);
			}
			$postData 		=	array(
				'item_name'	=>	$inputPost['item_name'],
				'price'		=>	$inputPost['price'],
				'qty'		=>	$inputPost['qty']
			);

			//echo $request->file('image')->getSize(); die;
			//$fileObj = $request->file('image');
			//Get File Input
			if(Input::file('image')){

				try{
					$fileObj = Input::file('image');

					$fileName 		=	$fileObj->getClientOriginalName();
					$fileOrigExt 	=	$fileObj->getClientOriginalExtension();
					$fileSize		=	$fileObj->getSize();
					$fileType		=	$fileObj->getMimeType();

					$fileInputSize 	=	$fileObj->getClientSize();

					$pictureName	= 	time().'.'.$fileOrigExt;
					$publicPath 	=	app()->basePath('public/uploads/items/');

					$fileObj->move($publicPath, $pictureName);
					$postData['picture']	= $pictureName;
				}catch(FileNotFoundException $ex){
					echo 'Exception image: ';
					exit;
				}					
			}

			if($dataId > 0){				

				$objItems 	=	$itemsObj->update($postData);

			}else{
				$objItems 	=	Items::create($postData);
			}

			if($objItems){
				$respJSON   =   array(
                'status'    =>  1,
                'respCode'  =>  200,
                'message' 	=> 'New Items Modified'
            	);
            return response()->json($respJSON);
            exit;
			}
			$respJSON   =   array(
                'status'    =>  0,
                'respCode'  =>  401,
                'message' 	=> 'Items Insertion/Updation Failed!'
            	);
            return response()->json($respJSON);
            exit;
		}
	}
}
