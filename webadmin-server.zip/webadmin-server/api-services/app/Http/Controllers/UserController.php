<?php

namespace App\Http\Controllers;

use Laravel\Lumen\Routing\Controller as BaseController;
use DB;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Hash;

class UserController extends BaseController
{

    public function getUserById(Request $request){
		//Do the needful
		$userRecord 	=	User::where('id',$request->input('id'))->get();

		$respJSON   =   array(
			'status'    	=>  1,
			'respCode'  	=>  200,
			'userData'		=> $userRecord,
			'message' 		=> "User Total Record"
		);
		return response()->json($respJSON);
		exit;
	}
	
	public function exportRecord(){

		$userRecord 	=	User::get();

		//print_r($userRecord);
		echo json_encode($userRecord);
	}

    public function getTotalRecord(Request $request){

		$srchKey 	=	'';
		$userData 	=	User::get();
		if(!empty($request->input('srchKey'))){
			$srchKey = $request->input('srchKey');

			$userData 	=	User::where('username',$srchKey)
							->orWhere('first_name', 'like', '%' . $srchKey . '%')
							->orWhere('last_name', 'like', '%' . $srchKey . '%')
							->get();
		}	

		$pageLimit 	=	3;
		$totalData	=	$userData->count();
		$totalPage 	=	ceil(($totalData)/$pageLimit);
		
		$respJSON   =   array(
			'status'    	=>  1,
			'respCode'  	=>  200,
			'totalRecord'	=>	$totalData,
			'totalPage'		=>	$totalPage,
			'pageLimit'		=>	$pageLimit,
			'message' 		=> "User Total Record"
		);
		return response()->json($respJSON);
		exit;
	}
	
	public function getListRecord(Request $request){

		$limitNum	=	0;
		$pageNum	=	0;
		$srchKey	=	'';

		$sortByField 	=	'first_name';
		$sortByDir 		=	'asc';
		
		if(empty($request->input('limitNum')) && 
			empty($request->input('pageNum'))){

			/*$userData 	=	User::get();
			$respJSON   =   array(
				'status'    	=>  1,
				'respCode'  	=>  200,
				'record'		=>	$userData,
				'message' 		=> "##User List Record"
			);*/
			$respJSON   =   array(
				'status'    	=>  0,
				'respCode'  	=>  400,
				'message' 		=> "Limit and Page Number empty"
			);
			return response()->json($respJSON);   
			exit;
		}
		//return response()->json($respJSON);
		//exit;
		
		if(!empty($request->input('limitNum'))){
			$limitNum = $request->input('limitNum');
		}
		if(!empty($request->input('pageNum'))){
			$pageNum = $request->input('pageNum');
		}
		if(!empty($request->input('srchKey'))){
			$srchKey = $request->input('srchKey');
		}
		if(!empty($request->input('queryType'))){
			$queryType = $request->input('queryType');
		}


		if(!empty($queryType) && $queryType === 'sort'){
			if(!empty($request->input('sortByField'))){
				$sortByField = $request->input('sortByField');
			}
			if(!empty($request->input('sortByDir'))){
				$sortByDir = $request->input('sortByDir');
			}
		}
		//$userData 	=	User::orderBy($sortByField, $sortByDir)
							//->paginate($limitNum);
		/*$userData 		=	User::skip(($pageNum - 1) * $limitNum)
		->take($limitNum)
		->orderBy($sortByField, $sortByDir)
		->get();*/
		//echo $pageNum.' => '.$limitNum;

		if(!empty($queryType) && $queryType === 'sort'){
			$userData 	=	User::forPage($pageNum,$limitNum)
							->orderBy($sortByField, $sortByDir)
							->get();
		}
		if(empty($queryType)){
			$userData 	=	User::forPage($pageNum,$limitNum)
							->get();
		}

		if(!empty($srchKey) && !empty($queryType) && $queryType === 'sort'){
			$userData 	=	User::where('username',$srchKey)
							->orWhere('first_name', 'like', '%' . $srchKey . '%')
							->orWhere('last_name', 'like', '%' . $srchKey . '%')
							->orWhere('email', 'like', '%' . $srchKey . '%')
							->forPage($pageNum,$limitNum)
							->orderBy($sortByField, $sortByDir)
							->get();
		}
		if(!empty($srchKey) && empty($queryType)){
			$userData 	=	User::where('username',$srchKey)
							->orWhere('first_name', 'like', '%' . $srchKey . '%')
							->orWhere('last_name', 'like', '%' . $srchKey . '%')
							->orWhere('email', 'like', '%' . $srchKey . '%')
							->forPage($pageNum,$limitNum)
							->get();
		}	

		$respJSON   =   array(
			'status'    	=>  1,
			'respCode'  	=>  200,
			'record'		=>	$userData,
			'message' 		=> "User List Record"
		);
		return response()->json($respJSON);
		exit;

	}

	public function editUser(Request $request){

		if(!$request->input('id')){
			$respJSON   =   array(
				'status'    	=>  0,
				'respCode'  	=>  400,
				'record'		=>	NULL,
				'message' 		=> "Please provide valid ID"
			);
			return response()->json($respJSON);
			exit;
		}

		$userRecord 	=	User::where('id',$request->input('id'))->get();

		$respJSON   =   array(
			'status'    	=>  1,
			'respCode'  	=>  200,
			'record'		=>	$userRecord,
			'message' 		=> "Selected User Record"
		);
		return response()->json($respJSON);
		exit;
	}

	public function deleteUser(Request $request){

		if(!$request->input('id')){
			$respJSON   =   array(
				'status'    	=>  0,
				'respCode'  	=>  400,
				'record'		=>	NULL,
				'message' 		=> "Please provide valid ID"
			);
			return response()->json($respJSON);
			exit;
		}
		$userDelete 	=	User::where('id',$request->input('id'))->delete();
		$respJSON   =   array(
			'status'    	=>  1,
			'respCode'  	=>  200,
			'record'		=>	$userDelete,
			'message' 		=> "Selected User Deleted"
		);
		return response()->json($respJSON);
		exit;
	}

	public function savingProfile(Request $request){

		$errValidate 	=	array();
		$errString 		=	'';	
		$arrayData		=	array();
		$inputPost 		=	$request->all();
		$dataId 		=	'';

		if($request->input('id')){
			$dataId 	=	$request->input('id');
		}

		$validation = Validator::make($request->all(),
		    [
	        	'first_name' 	=> 'required',
	        	'last_name' 	=> 'required'
        	]
		);

        if($validation->fails()){
        	$errorsValidation 	=	$validation->messages();
        	if(!empty($errorsValidation)){
        		foreach ( $errorsValidation->all() as $error ) {
			        array_push($errValidate,$error);
			    }
        	}
        	$respJSON   =   array(
                'status'    =>  0,
                'respCode'  =>  400,
                'message' => $errValidate
            );
            return response()->json($respJSON);
            exit;
		}

		if($inputPost){
			if($dataId > 0){
				$userObj 				=	User::findOrFail($dataId);
			}
			$postData 		=	array(
				'first_name'	=>	$inputPost['first_name'],
				'last_name'		=>	$inputPost['last_name']
			);

			if($dataId > 0){
				$objUser 	=	$userObj->update($postData);
			}

			if($objUser){
				$respJSON   =   array(
                'status'    =>  1,
                'respCode'  =>  200,
                'message' 	=> 'Profile Updated'
            	);
            return response()->json($respJSON);
            exit;
			}
			$respJSON   =   array(
                'status'    =>  0,
                'respCode'  =>  401,
                'message' 	=> 'Profile Updated Failed!'
            	);
            return response()->json($respJSON);
            exit;
		}
	}

    public function savingUser(Request $request){

		$errValidate 	=	array();
		$errString 		=	'';	
		$arrayData		=	array();
		$inputPost 		=	$request->all();
		$dataId 		=	'';

		if($request->input('id')){
			$dataId 	=	$request->input('id');
		}

		//print_r($request->file('userPhoto'));		
		//echo 'sss '.$request->file('userPhoto')->getMimeType();
		//echo 'size::: '.$fileObj->getSize();

		try {
			$fileObj = $request->file('userPhoto');
		  }
		  catch (\FileNotFoundException $e) {
			echo 'Exception 1'.$e->getMessage();
			$respJSON   =   array(
                'status'    =>  0,
                'respCode'  =>  400,
                'message' => 'Please upload max file within 1 MB'
            );
            return response()->json($respJSON);
            exit;
		}
		catch (\ErrorException $e) {
			echo 'Exception 2'.$e->getMessage();
			$respJSON   =   array(
                'status'    =>  0,
                'respCode'  =>  400,
                'message' => 'Please upload max file within 1 MB'
            );
            return response()->json($respJSON);
            exit;
		}
		  //

		//die;

		$validation = Validator::make($request->all(),
		    [
				'username' 		=> 'required|unique:ng_user,username,'.$dataId,
				'email'			=> 'required|unique:ng_user,email,'.$dataId,
	        	'first_name' 	=> 'required',
	        	'last_name' 	=> 'required',
				'password' 		=> 'required',
				'address'		=>	''
				//'userPhoto'		=> 'image|max:7200kb|mimes:jpeg,jpg,png'
        	]
		);

        if($validation->fails()){
        	$errorsValidation 	=	$validation->messages();
        	if(!empty($errorsValidation)){
        		foreach ( $errorsValidation->all() as $error ) {
			        array_push($errValidate,$error);
			    }
        	}
        	$respJSON   =   array(
                'status'    =>  0,
                'respCode'  =>  400,
                'message' => $errValidate
            );
            return response()->json($respJSON);
            exit;
		}

		//die;

		if($inputPost){
			if($dataId > 0){
				$userObj 				=	User::findOrFail($dataId);
			}
			$postData 		=	array(
				'first_name'	=>	$inputPost['first_name'],
				'last_name'		=>	$inputPost['last_name'],
				'email'			=>	$inputPost['email'],
				'username'		=>	$inputPost['username'],
				'address'		=>	isset($inputPost['address']) ? $inputPost['address'] : '',
				'password' 		=>	($dataId > 0) ? $userObj->password : md5($inputPost['password'])
			);

			//echo $request->file('userPhoto')->getSize(); die;
			//$fileObj = $request->file('userPhoto');
			//Get File Input
			if(Input::file('userPhoto')){

				try{
					$fileObj = Input::file('userPhoto');

					$fileName 		=	$fileObj->getClientOriginalName();
					$fileOrigExt 	=	$fileObj->getClientOriginalExtension();
					$fileSize		=	$fileObj->getSize();
					$fileType		=	$fileObj->getMimeType();

					$fileInputSize 	=	$fileObj->getClientSize();

					$pictureName = time().'.'.$fileOrigExt;
					$publicPath 	=	app()->basePath('public/uploads/user/');
					$fileObj->move($publicPath, $pictureName);
					$postData['profile_pic']	= $pictureName;
				}catch(FileNotFoundException $ex){
					echo 'Exception image: ';
					exit;
				}
					
			}
			//$image = Input::file('userPhoto');

			// $fileObj = Input::file('userPhoto');
			// echo 'Type: '.$fileType		=	$fileObj->getMimeType();
			// print_r($fileObj);

			//die;
			if($dataId > 0){
				$objUser 	=	$userObj->update($postData);
			}else{
				$objUser 	=	User::create($postData);
			}

			if($objUser){
				$respJSON   =   array(
                'status'    =>  1,
                'respCode'  =>  200,
                'message' 	=> 'New User Modified'
            	);
            return response()->json($respJSON);
            exit;
			}
			$respJSON   =   array(
                'status'    =>  0,
                'respCode'  =>  401,
                'message' 	=> 'User Insertion/Updation Failed!'
            	);
            return response()->json($respJSON);
            exit;
		}
	}
}
