<?php

namespace App\Http\Controllers;

use Validator;
use App\User;
use Cookie;

use Firebase\JWT\JWT;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
//use Illuminate\Contracts\Validation\Validator;
//use Illuminate\Support\Facades\Validator;
//use Illuminate\Validation\Validator;


use Firebase\JWT\ExpiredException;
use Illuminate\Support\Facades\Hash;
use Laravel\Lumen\Routing\Controller as BaseController;

class AuthController extends BaseController 
{
    /**
     * The request instance.
     *
     * @var \Illuminate\Http\Request
     */
    private $request;

    /**
     * Create a new controller instance.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return void
     */
    public function __construct(Request $request) {
        $this->request = $request;
    }

    /**
     * Create a new token.
     * 
     * @param  \App\User   $user
     * @return string
     */
    protected function jwt(User $user) {
        $payload = [
            'iss' => "lumen-jwt", // Issuer of the token
            'sub' => $user->id, // Subject of the token
            'iat' => time(), // Time when JWT was issued. 
            'exp' => time() + 60*60 // Expiration time
        ];
        
        // As you can see we are passing `JWT_SECRET` as the second parameter that will 
        // be used to decode the token in the future.
        return JWT::encode($payload, env('JWT_SECRET'));
    }

    /**
     * Check is Login @Admin.
     * 
     * @param  jwt Token already issued
     * @return boolean
     */
    public function isAdminLogin(Request $request){

        //echo '....';exit;

        $getToken       = $request->input('token');
        $token          = JWT::decode($getToken,'JhbGciOiJIUzI1N0eXAiOiJKV1QiLC',array('HS256'));
        if(!$getToken){
            $respJSON   =   array(
                'status'    =>  0,
                'respCode'  =>  500,
                'message'   =>  'Please request with valid token'
            );
            return response()->json($respJSON);
            exit;
        }
        $respJSON   =   array(
            'status'    =>  1,
            'respCode'  =>  200,
            'message'   =>  'Valid Token'
        );
        return response()->json($respJSON);
        exit;
    }

    /**
    *   Get Valid Token
    *
    *
    */
    public function getToken(){

        $objUser    =   new User();
        $tokenData  =   $this->jwt($objUser);

        if($tokenData){
            $respJSON   =   array(
            'status'    =>  1,
            'respCode'  =>  200,
            'adminToken' => $tokenData
            );
        return response()->json($respJSON);
        exit;
        }
    }

    /**
     * Authenticate a user and return the token if the provided credentials are correct.
     * 
     * @param  \App\User   $user 
     * @return mixed
     */
    public function login(Request $request, Response $response) {
        $errValidate 	=	array();
        $validation = Validator::make($request->all(),
		    [
	        	'username' 		=> 'required',
	        	'password' 		=> 'required'
        	]
		);

        if($validation->fails()){
        	$errorsValidation 	=	$validation->messages();
        	if(!empty($errorsValidation)){
        		foreach ( $errorsValidation->all() as $error ) {
			        array_push($errValidate,$error);
			    }
        	}
        	$respJSON   =   array(
                'status'    =>  0,
                'respCode'  =>  400,
                'message' 	=> $errValidate
            );
            return response()->json($respJSON);
            exit;
        }

        // Find the user by email
        $user = User::where('username', $request->input('username'))->first();
        if (!$user) {
         
            $respJSON   =   array(
                'status'    =>  0,
                'respCode'  =>  400,
                'message'      =>  'Username does not exist.'
            );

            return response()->json($respJSON);
            exit;
        }

        //print_r($user); die;

        if($user){
            $userCheck = User::where('is_admin', 1)
            ->where('password', md5($this->request->input('password')))
            ->get();

            if($userCheck->count()){                    
                    $respJSON   =   array(
                        'status'    =>  1,
                        'respCode'  =>  200,
                        'message'      =>  'User Found',
                        'user_id'       => $user->id,
                        'loginToken'    => $this->jwt($user),
                        'picture'   =>  $user->profile_pic 
                    );

                    return response()->json($respJSON);
                    exit;
                }

            if($userCheck->Count() == 0) {
                // Bad Request response
                $respJSON   =   array(
                    'status'    =>  0,
                    'respCode'  =>  400,
                    'message'      =>  'Username or Password is wrong!'
                );
                return response()->json($respJSON);
                exit;
            }
        }
    }
}
