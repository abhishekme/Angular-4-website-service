<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$app->get('/', function () use ($app) {
    return $app->version();
});

$app->group(['middleware' => 'App\Http\Middleware\CorsMiddleware','prefix' => 'api' , 'namespace' => 'App\Http\Controllers'], function() use ($app) {
    $app->post('/auth/login', [
        'uses' => 'AuthController@login'
    ]);
    
});


$app->get('is-login-token', [
        'uses' => 'AuthController@getToken'
]);
$app->get('uploads/user', [
    'uses' => 'AuthController@getToken'
]);

$app->group(['middleware' => 'jwt.auth','prefix' => 'api'], function() use ($app) {
    
    //Get User Route
    $app->post('item-total-record', [
        'as' => 'totalItem', 'uses' => 'App\Http\Controllers\ItemsController@getTotalRecord'
    ]);
    $app->post('item-by-id', [
        'as' => 'getItem', 'uses' => 'App\Http\Controllers\ItemsController@getRecordById'
    ]);
    $app->post('item-export', [
        'as' => 'exportItem', 'uses' => 'App\Http\Controllers\ItemsController@exportRecord'
    ]);
    $app->post('item-list-record', [
        'as' => 'getItemList', 'uses' => 'App\Http\Controllers\ItemsController@getListRecord'
    ]);
    //$app->post('item-create', [
        //'uses' => 'App\Http\Controllers\ItemsController@createUser'
    //]);
    $app->post('item-save', [
        'as' => 'itemSave', 'uses' => 'App\Http\Controllers\ItemsController@savingItems'
    ]);
    $app->post('item-edit', [
        'as' => 'itemEdit', 'uses' => 'App\Http\Controllers\ItemsController@editItems'
    ]);
    $app->post('item-delete', [
        'as' => 'itemDelete', 'uses' => 'App\Http\Controllers\ItemsController@deleteItems'
    ]);


    //Get Country Route
    $app->post('country-total-record', [
        'as' => 'totalCountry', 'uses' => 'App\Http\Controllers\CountryController@getTotalRecord'
    ]);
    $app->post('country-by-id', [
        'as' => 'getCountry', 'uses' => 'App\Http\Controllers\CountryController@getRecordById'
    ]);

    $app->post('state-by-country', [
        'as' => 'getStateByCountry', 'uses' => 'App\Http\Controllers\CountryController@getStateByCountry'
    ]);

    $app->post('country-list-record', [
        'as' => 'countryList', 'uses' => 'App\Http\Controllers\CountryController@getListRecord'
    ]);
    $app->post('country-save', [
        'as' => 'countrySave', 'uses' => 'App\Http\Controllers\CountryController@savingRecord'
    ]);
    $app->post('country-edit', [
        'as' => 'countryEdit', 'uses' => 'App\Http\Controllers\CountryController@editRecord'
    ]);
    $app->post('country-delete', [
        'as' => 'countryDelete', 'uses' => 'App\Http\Controllers\CountryController@deleteRecord'
    ]);


    //Get User Route
    $app->post('user-total-record', [
        'as' => 'totalUser', 'uses' => 'App\Http\Controllers\UserController@getTotalRecord'
    ]);
    $app->post('user-by-id', [
        'as' => 'getUser', 'uses' => 'App\Http\Controllers\UserController@getUserById'
    ]);
    $app->post('user-export', [
        'as' => 'exportUser', 'uses' => 'App\Http\Controllers\UserController@exportRecord'
    ]);
    $app->post('user-list-record', [
        'as' => 'userList', 'uses' => 'App\Http\Controllers\UserController@getListRecord'
    ]);
    $app->post('isAdminLogin', [
        'uses' => 'App\Http\Controllers\AuthController@isAdminLogin'
    ]);
    $app->post('user-create-user', [
        'uses' => 'App\Http\Controllers\UserController@createUser'
    ]);
    $app->post('user-save', [
        'as' => 'userSave', 'uses' => 'App\Http\Controllers\UserController@savingUser'
    ]);
    $app->post('profile-update', [
        'as' => 'profileSave', 'uses' => 'App\Http\Controllers\UserController@savingProfile'
    ]);
    $app->post('user-edit', [
        'as' => 'userEdit', 'uses' => 'App\Http\Controllers\UserController@editUser'
    ]);
    $app->post('user-delete', [
        'as' => 'userDelete', 'uses' => 'App\Http\Controllers\UserController@deleteUser'
    ]);

    //Get Form Route
    $app->post('form-total-record', [
        'as' => 'totalRecord', 'uses' => 'App\Http\Controllers\FormController@getTotalRecord'
    ]);
    $app->post('form-by-id', [
        'as' => 'getRecord', 'uses' => 'App\Http\Controllers\FormController@getRecordById'
    ]);
    $app->post('form-export', [
        'as' => 'exportRecord', 'uses' => 'App\Http\Controllers\FormController@exportRecord'
    ]);
    $app->post('form-list-record', [
        'as' => 'listRecord', 'uses' => 'App\Http\Controllers\FormController@getListRecord'
    ]);
    $app->post('form-save', [
        'as' => 'recordSave', 'uses' => 'App\Http\Controllers\FormController@savingRecord'
    ]);
    $app->post('form-edit', [
        'as' => 'recordEdit', 'uses' => 'App\Http\Controllers\FormController@editRecord'
    ]);
    $app->post('form-delete', [
        'as' => 'recordDelete', 'uses' => 'App\Http\Controllers\FormController@deleteRecord'
    ]);

});


