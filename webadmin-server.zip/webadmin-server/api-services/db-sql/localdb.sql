-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 03, 2018 at 06:40 PM
-- Server version: 5.7.23-0ubuntu0.16.04.1
-- PHP Version: 7.0.30-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `localdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `form_multi`
--

CREATE TABLE `form_multi` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `sel_one` varchar(50) NOT NULL,
  `sel_multi` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `file` varchar(100) NOT NULL,
  `sel_radio` varchar(50) NOT NULL,
  `sel_check` varchar(10) NOT NULL,
  `created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_multi`
--

INSERT INTO `form_multi` (`id`, `email`, `password`, `sel_one`, `sel_multi`, `content`, `file`, `sel_radio`, `sel_check`, `created`) VALUES
(3, 'abhishek.me1977@gmail.com', 'e19d5cd5af0378da05f63f891c7467af', '3', '2,3,5', 'Test data, Test data, Test data, Test data, Test data, Test data, Test data, Test data, Test data, Test data, Test data, Test data, Test data, Test data, Test data, Test data, Test data, Test data.gg', '1533032789.jpg', 'option2', 'true', '0000-00-00'),
(4, 'abhishek.me77@gmail.com', '1a100d2c0dab19c4430e7d73762b3423', '2', '1,3,5', 'Lorem ipsum dolors amets, Lorem ipsum dolors amets, Lorem ipsum dolors amets, Lorem ipsum dolors amets, Lorem ipsum dolors amets, Lorem ipsum dolors amets, Lorem ipsum dolors amets, Lorem ipsum dolors amets, Lorem ipsum dolors amets, Lorem ipsum dolors amets, Lorem ipsum dolors amets, Lorem ipsum dolors amets, Lorem ipsum dolors amets, Lorem ipsum dolors amets.', '1533035655.jpg', 'option3', 'true', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `ng_user`
--

CREATE TABLE `ng_user` (
  `id` int(11) NOT NULL,
  `first_name` varchar(45) COLLATE latin2_bin DEFAULT NULL,
  `last_name` varchar(45) COLLATE latin2_bin DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `username` varchar(50) COLLATE latin2_bin NOT NULL,
  `email` varchar(45) COLLATE latin2_bin DEFAULT NULL,
  `password` varchar(100) COLLATE latin2_bin DEFAULT NULL,
  `address` varchar(45) COLLATE latin2_bin DEFAULT NULL,
  `profile_pic` varchar(150) COLLATE latin2_bin DEFAULT NULL,
  `remember_token` varchar(150) COLLATE latin2_bin NOT NULL,
  `is_admin` int(5) DEFAULT NULL,
  `status` int(5) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin2 COLLATE=latin2_bin;

--
-- Dumping data for table `ng_user`
--

INSERT INTO `ng_user` (`id`, `first_name`, `last_name`, `date_of_birth`, `username`, `email`, `password`, `address`, `profile_pic`, `remember_token`, `is_admin`, `status`) VALUES
(16, 'Subir', 'Chattaraj', NULL, 'superadmin', 'admin@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'Demo', '1531295248.jpg', '', 1, 1),
(20, 'Abhigna das', 'Das', NULL, 'abhigna-ghatu', 'admin-abhigna@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'Thakurpukur M.G.ROAD Kolkata 700104', '1531749999.jpg', '', 1, 1),
(21, 'ssfafsafs', 'sasfasfas', NULL, 'asfasfsfa', 'sfafasf@aaa.com', 'f4cc399f0effd13c888e310ea2cf5399', 'address', '1530979364.jpg', '', NULL, 1),
(22, 'Test Ghatu', 'Das', NULL, 'fffasfasfsfa', 'sfafasfdd@aaa.com', 'c56d0e9a7ccec67b4ea131655038d604', 'address123', '1530817891.jpeg', '', NULL, 1),
(23, 'Testd', 'ssdasda', NULL, 'saafasf', 'sdasda@aaa.com', '2f7b52aacfbf6f44e13d27656ecb1f59', 'Test address', '1531301545.jpg', '', NULL, 1),
(27, 'Abhigna', 'Das Ghatum', NULL, 'abhigna-ghatu-mana', 'admin-abhigna-mana@gmail.com', '9c48ce8da7208b352c9c52618aa1822b', 'Thakurpukur 123\r\n', '1531749964.jpg', '', NULL, 1),
(28, 'gfhfghfhf', 'fghfghfgh', NULL, 'sssss', 'ddddd@aaaa.com', '202cb962ac59075b964b07152d234b70', '', NULL, '', NULL, 1),
(30, 'Abhishek777', 'Das123', '1977-06-29', 'james_bond_00753', 'admin@gmail.com', '$2y$10$nwbD2tp5dr.b4JZh8jcPReSXQODKtfN9lrDYhOlc/W707h.frZjW6', NULL, 'http://localhost:1337/assets/images/uploads/0b5340ee-e6e7-4dc1-9e77-2d8615153c2f.jpg', 'MxbDAM55On8oJkisEAehfX3s6UMuDJy4u3bbAnG30TvVjcZ52c59TMYXsw4q', 1, 1),
(32, 'allah', 'rakha', '2018-05-05', 'allaRakha', 'das.abhishek77@gmail.com', '$2y$10$nwbD2tp5dr.b4JZh8jcPReSXQODKtfN9lrDYhOlc/W707h.frZjW6', NULL, '', '', 0, 1),
(33, 'dfgdfgdf', 'dfgdfgdfg', '2018-04-10', 'aaaabbbbcccckkkk', 'fgfgdg@aaaaa.com', 'bfe48456aefe6a834912d7fc7482f04a', NULL, '', '', 0, 1),
(34, 'fgdfg', 'dfgdfgdfgd', '2018-04-11', 'pppgggaaa', 'dfgfgfd@aaaa.com', 'e10adc3949ba59abbe56e057f20f883e', NULL, '', '', 0, 1),
(35, 'pppgghhhkk', 'ggg', '2018-04-10', 'pppddff', 'pppfff@aa.com', 'e10adc3949ba59abbe56e057f20f883e', NULL, '', '', 0, 1),
(36, 'gfhfghfgh', 'fghfghfg', '2018-04-10', 'pppgggdd', 'dsfsds@aaa.com', 'e10adc3949ba59abbe56e057f20f883e', NULL, '', '', 0, 1),
(37, 'ppppp', 'ddd', '2018-04-10', 'pppdddff', 'pppdd@aaa.com', 'e10adc3949ba59abbe56e057f20f883e', NULL, '', '', 0, 1),
(38, 'dfgdfgdf', 'dfgdfgdfgdf', '2018-04-10', 'saswat', 'saswatroutroy@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', NULL, '', '', 0, 1),
(39, 'ddfsddsfds', 'dsfsdfsdf', '2018-04-10', 'dsfdsfsdfsd', 'sdfsdsdf@aaa.com', 'e10adc3949ba59abbe56e057f20f883e', NULL, '', '', 0, 1),
(40, 'ddfsddsfds', 'dsfsdfsdf', '2018-04-10', 'dsfdsfsdfsdfff', 'sdfsdsdfddd@aaa.com', 'e10adc3949ba59abbe56e057f20f883e', NULL, '', '', 0, 1),
(41, 'dfdssd', 'sdfsdfsdfs', '2018-04-10', 'saswatrout', 'saswatrout@gmail.com', '$2y$10$nwbD2tp5dr.b4JZh8jcPReSXQODKtfN9lrDYhOlc/W707h.frZjW6', NULL, '', '', 0, 1),
(42, 'dfdssd', 'sdfsdfsdfs', '2018-04-10', 'saswatroutabcdaa', 'saswatroutbbb@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', NULL, '', '', 0, 1),
(43, 'sdfsdfsdfsd', 'dsfsdfsdfsd', '2018-04-10', 'dsfsdffsdSaswat', 'abcdsaswatroutbbb@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', NULL, '', '', 0, 1),
(44, 'dfgdfgdfgdf', 'dfgdfgd', '2018-04-10', 'fdgddfgdg', 'dfgdfgdf@aaa.com', 'e10adc3949ba59abbe56e057f20f883e', NULL, '', '', 0, 1),
(45, 'fghfghf', 'fghfghfgh', '2018-04-10', 'fghfghfhgf', 'fghfgf@aaa.com', '2be9bd7a3434f7038ca27d1918de58bd', NULL, '', '', 0, 1),
(46, 'dfgdfgf', 'dfgdfgd', '2018-04-10', 'fdghfghfsss', 'sdfsdfsdfaaa@aa.com', 'e10adc3949ba59abbe56e057f20f883e', NULL, '', '', 0, 1),
(47, 'fghgdfgdf', 'fhfghfg', '2018-04-10', 'Abhishekbbbb', 'fdgdfgdf@aaa.com', 'b59c67bf196a4758191e42f76670ceba', NULL, '', '', 0, 1),
(48, 'sdfsdfsdds', 'sdfsdfsdfsd', '2018-04-11', 'sdfsdfsdf', 'dsfsdfsd@aaa.com', 'dbc4d84bfcfe2284ba11beffb853a8c4', NULL, '', '', 0, 1),
(49, 'hgfhgfh', 'fghfghfg', '2018-04-10', 'hfghfghgf', 'gfhfghfg@aaa.com', '3f947887db241dbb412f134a03b88e5e', NULL, '', '', 0, 1),
(50, 'gfhgf', 'ghgfhgf', '1977-06-29', 'gfghgfh', 'gfhgfh@aaa.com', '96e79218965eb72c92a549dd5a330112', NULL, '', '', 0, 1),
(51, 'ghgfh fgfg', 'fghfghfghgf', NULL, 'fghfghgf', 'fghfg@aaaa.com', 'dbc4d84bfcfe2284ba11beffb853a8c4', '', '1532946034.jpg', '', NULL, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `form_multi`
--
ALTER TABLE `form_multi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ng_user`
--
ALTER TABLE `ng_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `form_multi`
--
ALTER TABLE `form_multi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `ng_user`
--
ALTER TABLE `ng_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
