<?php

namespace App\Http\Controllers;

use Laravel\Lumen\Routing\Controller as BaseController;
use DB;
use App\Form;
use Validator;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Hash;

class FormController extends BaseController
{

    public function getRecordById(Request $request){
		//Do the needful
		$dataRecord 	=	Form::where('id',$request->input('id'))->get();

		$respJSON   =   array(
			'status'    	=>  1,
			'respCode'  	=>  200,
			'recordData'	=> $dataRecord,
			'message' 		=> "Total Record By ID"
		);
		return response()->json($respJSON);
		exit;
	}
	
	public function exportRecord(){

		$dataRecord 	=	Form::get();
		echo json_encode($dataRecord);
	}

    public function getTotalRecord(Request $request){

		$srchKey 	=	'';
		$recordData 	=	Form::get();
		if(!empty($request->input('srchKey'))){
			$srchKey = $request->input('srchKey');

			$recordData 	=	Form::where('email',$srchKey)
								->orWhere('content', 'like', '%' . $srchKey . '%')
								->get();
		}	

		$pageLimit 	=	3;
		$totalData	=	$recordData->count();
		$totalPage 	=	ceil(($totalData)/$pageLimit);
		
		$respJSON   =   array(
			'status'    	=>  1,
			'respCode'  	=>  200,
			'totalRecord'	=>	$totalData,
			'totalPage'		=>	$totalPage,
			'pageLimit'		=>	$pageLimit,
			'message' 		=> "Total Record"
		);
		return response()->json($respJSON);
		exit;
	}
	
	public function getListRecord(Request $request){

		$limitNum	=	0;
		$pageNum	=	0;
		$srchKey	=	'';

		$sortByField 	=	'email';
		$sortByDir 		=	'asc';

		if(empty($request->input('limitNum')) && 
			empty($request->input('pageNum'))){
			
			$respJSON   =   array(
				'status'    	=>  0,
				'respCode'  	=>  400,
				'message' 		=> "Limit and Page Number empty"
			);
			return response()->json($respJSON);
			exit;
		}

		if(!empty($request->input('limitNum'))){
			$limitNum = $request->input('limitNum');
		}
		if(!empty($request->input('page'))){
			$pageNum = $request->input('page');
		}
		if(!empty($request->input('srchKey'))){
			$srchKey = $request->input('srchKey');
		}
		if(!empty($request->input('sortByField'))){
			$sortByField = $request->input('sortByField');
		}
		if(!empty($request->input('sortByDir'))){
			$sortByDir = $request->input('sortByDir');
		}
		
		$recordData 	=	Form::forPage($pageNum,$limitNum)
						->orderBy($sortByField, $sortByDir)
						->get();
		if(!empty($srchKey)){
			$recordData 	=	Form::where('email',$srchKey)
							->orWhere('content', 'like', '%' . $srchKey . '%')
							->forPage($pageNum,$limitNum)
							->orderBy($sortByField, $sortByDir)
							->get();			
		}
		//echo '<pre>';
		//print_r($recordData); die;

		$respJSON   =   array(
			'status'    	=>  1,
			'respCode'  	=>  200,
			'record'		=>	$recordData,
			'message' 		=> "List Record"
		);
		return response()->json($respJSON);
		exit;

	}

	public function editRecord(Request $request){

		if(!$request->input('id')){
			$respJSON   =   array(
				'status'    	=>  0,
				'respCode'  	=>  400,
				'record'		=>	NULL,
				'message' 		=> "Please provide valid ID"
			);
			return response()->json($respJSON);
			exit;
		}
		$dataRecord 	=	Form::where('id',$request->input('id'))->get();

		$respJSON   =   array(
			'status'    	=>  1,
			'respCode'  	=>  200,
			'record'		=>	$dataRecord,
			'message' 		=> "Selected Record"
		);
		return response()->json($respJSON);
		exit;
	}

	public function deleteRecord(Request $request){

		if(!$request->input('id')){
			$respJSON   =   array(
				'status'    	=>  0,
				'respCode'  	=>  400,
				'record'		=>	NULL,
				'message' 		=> "Please provide valid ID"
			);
			return response()->json($respJSON);
			exit;
		}
		$recordDelete 	=	Form::where('id',$request->input('id'))->delete();
		$respJSON   =   array(
			'status'    	=>  1,
			'respCode'  	=>  200,
			'record'		=>	$recordDelete,
			'message' 		=> "Selected Record Deleted"
		);
		return response()->json($respJSON);
		exit;
	}

    public function savingRecord(Request $request){

		$errValidate 	=	array();
		$errString 		=	'';	
		$arrayData		=	array();
		$inputPost 		=	$request->all();
		$dataId 		=	'';

		if($request->input('id')){
			$dataId 	=	$request->input('id');
		}

		try {
			$fileObj = $request->file('fileinput');
		  }
		  catch (\FileNotFoundException $e) {
			echo 'Exception 1'.$e->getMessage();
			$respJSON   =   array(
                'status'    =>  0,
                'respCode'  =>  400,
                'message' => 'Please upload max file within 1 MB'
            );
            return response()->json($respJSON);
            exit;
		}
		catch (\ErrorException $e) {
			echo 'Exception 2'.$e->getMessage();
			$respJSON   =   array(
                'status'    =>  0,
                'respCode'  =>  400,
                'message' => 'Please upload max file within 1 MB'
            );
            return response()->json($respJSON);
            exit;
		}

		$validation = Validator::make($request->all(),
		    [
				'sel_one' 		=> 'required',
				'email'			=> 'required|email|unique:form_multi,email,'.$dataId,
	        	'sel_multi' 	=> 'required',
	        	'sel_radio' 	=> 'required',
				'password' 		=> 'required',
				'sel_check'		=> 'required'
        	]
		);

		/*echo 'post value';
		echo '<pre>';
		print_r($inputPost);
		exit;*/

        if($validation->fails()){
        	$errorsValidation 	=	$validation->messages();
        	if(!empty($errorsValidation)){
        		foreach ( $errorsValidation->all() as $error ) {
			        array_push($errValidate,$error);
			    }
        	}
        	$respJSON   =   array(
                'status'    =>  0,
                'respCode'  =>  400,
                'message' => $errValidate
            );
            return response()->json($respJSON);
            exit;
		}

		if($inputPost){
			if($dataId > 0){
				$userObj 				=	Form::findOrFail($dataId);
			}
			$postData 		=	array(
				'sel_one'		=>	$inputPost['sel_one'],
				'email'			=>	$inputPost['email'],
				'sel_multi'		=>	$inputPost['sel_multi'],
				'sel_radio'		=>	$inputPost['sel_radio'],
				'sel_check'		=>	($inputPost['sel_check']),
				'content'		=>	$inputPost['content'],
				'password' 		=>	($dataId > 0) ? $userObj->password : md5($inputPost['password'])
			);

			//Get File Input
			if(Input::file('fileinput')){

				try{
					$fileObj = Input::file('fileinput');

					$fileName 		=	$fileObj->getClientOriginalName();
					$fileOrigExt 	=	$fileObj->getClientOriginalExtension();
					$fileSize		=	$fileObj->getSize();
					$fileType		=	$fileObj->getMimeType();

					$fileInputSize 	=	$fileObj->getClientSize();

					$pictureName = time().'.'.$fileOrigExt;
					$publicPath 	=	app()->basePath('public/uploads/form-upload/');
					$fileObj->move($publicPath, $pictureName);
					$postData['file']	= $pictureName;
				}catch(FileNotFoundException $ex){
					echo 'Exception image: ';
					exit;
				}
			}

			if($dataId > 0){
				$objUser 	=	$userObj->update($postData);
			}else{
				$objUser 	=	Form::create($postData);
			}

			if($objUser){
				$respJSON   =   array(
                'status'    =>  1,
                'respCode'  =>  200,
                'message' 	=> 'New Form Modified'
            	);
            return response()->json($respJSON);
            exit;
			}
			$respJSON   =   array(
                'status'    =>  0,
                'respCode'  =>  401,
                'message' 	=> 'Form Insertion/Updation Failed!'
            	);
            return response()->json($respJSON);
            exit;
		}
	}
}
